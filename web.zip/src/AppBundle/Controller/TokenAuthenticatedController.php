<?php

namespace AppBundle\Controller;

interface TokenAuthenticatedController
{
    // ...
}