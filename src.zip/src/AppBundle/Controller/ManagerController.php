<?php

// src/AppBundle/Company/ManagerController.php
namespace AppBundle\Controller;

use ApiBundle\CompanyUserController;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use Symfony\Component\HttpFoundation\Request;


class ManagerController extends Controller
{
    /**
     * Matches /manager exactly
     *
     * @Route("/manager", name="manager")
     */
    public function indexAction(Request $request)
    {
     // @Security("has_role('ROLE_MANAGER')")

        // $siteManager = $this->container->get('site_manager');
       // $manager = {'title' : "Manager"};

       $this->isGranted('manage');

        return $this->render('default/index.html.twig', array(
            //'site' => $siteManager->getCurrentSite(),
        ));
    }
}
